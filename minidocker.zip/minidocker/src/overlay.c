#include <stdio.h>
#include <sys/stat.h>
#include <sys/mount.h>
#include "overlay.h"

int setup_overlay(const char *lower, const char *id, char *merged, int size) {
    char base[256], upper[300], work[300], opts[1000];
    mkdir("/tmp/minidocker", 0755);
    snprintf(base, sizeof(base), "/tmp/minidocker/%s", id);
    mkdir(base, 0755);
    snprintf(upper, sizeof(upper), "%s/upper", base);
    snprintf(work, sizeof(work), "%s/work", base);
    snprintf(merged, size, "%s/merged", base);
    mkdir(upper, 0755);
    mkdir(work, 0755);
    mkdir(merged, 0755);
    snprintf(opts, sizeof(opts), "lowerdir=%s,upperdir=%s,workdir=%s", lower, upper, work);
    if (mount("overlay", merged, "overlay", 0, opts) != 0) {
        perror("mount overlay");
        return -1;
    }
    return 0;
}
