#include <unistd.h>

void print_status(int pid);

int main() {
    print_status(getpid());
    return 0;
}
