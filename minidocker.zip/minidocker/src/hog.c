#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main() {
    int mb = 0;
    while (1) {
        char *p = malloc(1024 * 1024);
        if (!p) break;
        memset(p, 1, 1024 * 1024);
        printf("allocated %d MB\n", ++mb);
        fflush(stdout);
        usleep(100000);
    }
    return 0;
}
