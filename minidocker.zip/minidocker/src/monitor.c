#include <stdio.h>
#include <string.h>

void print_status(int pid) {
    char path[64], line[256];
    snprintf(path, sizeof(path), "/proc/%d/status", pid);
    FILE *f = fopen(path, "r");
    if (!f) { perror(path); return; }
    while (fgets(line, sizeof(line), f)) {
        if (strncmp(line, "State", 5) == 0 || strncmp(line, "VmRSS", 5) == 0)
            printf("%s", line);
    }
    fclose(f);
}
