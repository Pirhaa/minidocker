#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

void setup_cgroup(int pid, const char *mem, const char *pids);

int main() {
    pid_t pid = fork();
    if (pid == 0) {
        sleep(1);
        execl("./hog", "hog", NULL);
        perror("exec");
        return 1;
    }
    setup_cgroup(pid, "52428800", "20");
    int status;
    waitpid(pid, &status, 0);
    if (WIFSIGNALED(status))
        printf("Killed by signal %d\n", WTERMSIG(status));
    return 0;
}
