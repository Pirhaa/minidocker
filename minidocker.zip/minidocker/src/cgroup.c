#include <stdio.h>
#include <sys/stat.h>

static void w(const char *p, const char *v) {
    FILE *f = fopen(p, "w");
    if (!f) { perror(p); return; }
    fprintf(f, "%s", v);
    fclose(f);
}

void setup_cgroup(int pid, const char *mem, const char *pids) {
    mkdir("/sys/fs/cgroup/minidocker", 0755);
    w("/sys/fs/cgroup/cgroup.subtree_control", "+memory +pids");
    w("/sys/fs/cgroup/minidocker/cgroup.subtree_control", "+memory +pids");
    mkdir("/sys/fs/cgroup/minidocker/c1", 0755);
    w("/sys/fs/cgroup/minidocker/c1/memory.max", mem);
    w("/sys/fs/cgroup/minidocker/c1/memory.swap.max", "0");
    w("/sys/fs/cgroup/minidocker/c1/pids.max", pids);
    char s[32];
    snprintf(s, sizeof(s), "%d", pid);
    w("/sys/fs/cgroup/minidocker/c1/cgroup.procs", s);
}
