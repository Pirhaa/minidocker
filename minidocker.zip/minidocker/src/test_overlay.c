#include <stdio.h>
#include "overlay.h"

int main() {
    char merged[300];
    if (setup_overlay("/home/sibau/lowertest", "c1", merged, sizeof(merged)) == 0)
        printf("merged at: %s\n", merged);
    return 0;
}
