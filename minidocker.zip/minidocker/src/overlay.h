#ifndef OVERLAY_H
#define OVERLAY_H
int setup_overlay(const char *lower, const char *id, char *merged, int size);
#endif
